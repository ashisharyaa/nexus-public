Ext.define('Foo', {
  requires: [
    'Bar'
  ]
});
