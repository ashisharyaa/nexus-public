Ext.define('Bar', {
  requires: [
    'Baz'
  ]
});
