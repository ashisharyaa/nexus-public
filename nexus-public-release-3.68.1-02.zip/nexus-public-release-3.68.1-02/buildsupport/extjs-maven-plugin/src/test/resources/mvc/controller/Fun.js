Ext.define('Test.controller.Fun', {
  extend: 'Ext.app.Controller',

  stores: [
    'Fun'
  ],
  views: [
    'Fun'
  ]
});
