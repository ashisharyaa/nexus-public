Ext.define('Test.view.Fun', {
  extend: 'Ext.panel.Panel'
});
