Ext.define('Poo', {
  '@aggregate_priority': 9
});
