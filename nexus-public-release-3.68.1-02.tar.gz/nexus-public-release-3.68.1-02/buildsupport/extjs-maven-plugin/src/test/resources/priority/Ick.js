Ext.define('Ick', {
  '@aggregate_priority': 10,
  requires: [
    'Poo'
  ]
});
