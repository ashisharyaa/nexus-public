Ext.define('Test.model.Fun', {
  extend: 'Ext.data.Model'
});
