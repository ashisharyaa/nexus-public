Ext.define('Test.Application', {
  extend: 'Ext.app.Application',

  controllers: [
    'Fun'
  ]
});
