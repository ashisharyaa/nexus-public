Ext.define('Test.store.Fun', {
  extend: 'Ext.data.Store',
  model: 'Test.model.Fun'
});
