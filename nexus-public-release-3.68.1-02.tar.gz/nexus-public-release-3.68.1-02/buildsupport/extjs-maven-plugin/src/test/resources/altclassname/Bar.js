Ext.define('Bar', {
  alternateClassName: [
    'Test.Bar',
    'Other.Bar'
  ],
  requires: [
    'Baz'
  ]
});
