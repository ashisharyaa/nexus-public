Ext.define('Foo', {
  alternateClassName: 'Test.Foo',
  requires: [
    'Test.Bar'
  ]
});
